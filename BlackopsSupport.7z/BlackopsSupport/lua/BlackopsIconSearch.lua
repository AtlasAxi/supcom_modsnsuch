BlueprintLocations = {} # Create a nice global var.
BlueprintList = {} # Create a nice global var.

local FindBlueprintsCalled = false

function BlackopsBlueprintLocator()
    if not FindBlueprintsCalled then
        FindBlueprints() # This should ONLY be called on first finding of a custom icon. No more than once.
    end
end

function FindBlueprints()
    for id, mod in __active_mods do
        local blueprints = DiskFindFiles(mod.location, '*_unit.bp')
        for id, bp in blueprints do
            # Now we need to get the unit ID from the file path. string.sub does this job effectively.
            # Get rid of the string in the second argument.
            bp = string.gsub(bp, '_unit.bp', '')
 
            # URL0001, seven letters, and without _unit.bp, they're the last seven.
            # This does enforce seven-character unitIDs, but they can be any seven.
            bp = string.sub(bp, (string.len(bp) - 7), string.len(bp))
   
            bp = string.upper(string.gsub(bp,'/',''))
            BlueprintLocations[bp] = mod.location  # Store it off in our pre-defined global.
			BlueprintList[bp] = bp  # Store it off in our pre-defined global.
            FindBlueprintsCalled = true # Don't ever recall this function
        end
    end
end

function GetCustomIconLocation(unitID)
    unitID = string.upper(unitID)
        if not BlueprintList[unitID] then
            --LOG("Mod icons folder not found!", unitID)
			WARN('Blackops Support Alert: '.. unitID ..' is not a modded unit')
	        --LOG(unitID)
	        --LOG(repr(BlueprintLocations))
            return ''
        else
            return BlueprintLocations[unitID]
        end
end