do
local BlackopsIcons = import('/mods/BlackopsSupport/lua/BlackopsIconSearch.lua')

function GetUnitIconFileNames(blueprint)
    local iconName = '/textures/ui/common/icons/units/' .. blueprint.Display.IconName .. '_icon.dds'
    local upIconName = '/textures/ui/common/icons/units/' .. blueprint.Display.IconName .. '_build_btn_up.dds'
    local downIconName = '/textures/ui/common/icons/units/' .. blueprint.Display.IconName .. '_build_btn_down.dds'
    local overIconName = '/textures/ui/common/icons/units/' .. blueprint.Display.IconName .. '_build_btn_over.dds'
    
    if DiskGetFileInfo(iconName) == false then
        if BlackopsIcons.BlueprintList[string.upper(blueprint.BlueprintId)] then
            local modlocation = BlackopsIcons.GetCustomIconLocation(blueprint.BlueprintId)
            iconName = modlocation .. iconName
            if DiskGetFileInfo(modlocation .. upIconName) then
                upIconName = modlocation .. upIconName
            else
                upIconName = '/textures/ui/common/icons/units/default_icon.dds'
            end
            if DiskGetFileInfo(modlocation .. downIconName) then
                downIconName = modlocation .. downIconName
            else
                downIconName = '/textures/ui/common/icons/units/default_icon.dds'
            end
            if DiskGetFileInfo(modlocation .. overIconName) then
                overIconName = modlocation .. overIconName
            else
                overIconName = '/textures/ui/common/icons/units/default_icon.dds'
            end
        else
            iconName = '/textures/ui/common/icons/units/default_icon.dds'
            upIconName = '/textures/ui/common/icons/units/default_icon.dds'
            downIconName = '/textures/ui/common/icons/units/default_icon.dds'
            overIconName = '/textures/ui/common/icons/units/default_icon.dds'
        end
    end
    
    return iconName, upIconName, downIconName, overIconName
end

end