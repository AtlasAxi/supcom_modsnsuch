do

local BlackopsIcons = import('/mods/BlackopsSupport/lua/BlackopsIconSearch.lua')
BlackopsIcons.BlackopsBlueprintLocator()

end
