name = "BlackOps Global Icon Support Mod"
uid = "9e8ea941-c306-4751-b367-f00000000002"
version = 2
copyright = "2009 Exavier Macbeth, DeadMG"
description = "Version 2.0. This mod provides global icon support for any mod that places their icons in the proper folder structure. See Readme"
author = "Exavier Macbeth, DeadMG"
url = "http://forums.gaspowered.com/viewtopic.php?t=36996"
icon = "/mods/BlackopsSupport/earth.png"
selectable = true
enabled = true
exclusive = false
ui_only = false
requires = { }
requiresNames = { }
conflicts = { }
before = { }
after = { }
