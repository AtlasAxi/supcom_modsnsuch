name = "BlackOps Adv Command Units"
uid = "9e8ea941-c306-4751-b367-e00000000208"
version = 6
copyright = "2009 Exavier Macbeth"
description = "Version 2.8. Redesigns ACU and SCU Upgrades for More Options. Increases ACUs power to experimental levels as upgraded."
author = "Exavier Macbeth"
url = "http://forums.gaspowered.com/viewtopic.php?t=35265"
icon = "/mods/BlackopsACUs/icon.png"
selectable = true
enabled = true
exclusive = false
ui_only = false
requires = { "9e8ea941-c306-4751-b367-f00000000002" }
requiresNames = { }
conflicts = { }
before = { }
after = { }
